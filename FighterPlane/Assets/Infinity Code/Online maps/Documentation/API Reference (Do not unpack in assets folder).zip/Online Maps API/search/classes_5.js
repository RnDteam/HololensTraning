var searchData=
[
  ['fare',['Fare',['../classOnlineMapsGoogleDirectionsResult_1_1Fare.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['feature',['Feature',['../classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html',1,'OnlineMapsHereRoutingAPI::RoutingMode']]]
];
