var searchData=
[
  ['valueenumerator',['ValueEnumerator',['../classOnlineMapsJSONValue_1_1ValueEnumerator.html',1,'OnlineMapsJSONValue']]],
  ['vehicle',['Vehicle',['../classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['vehicletype',['VehicleType',['../classOnlineMapsHereRoutingAPI_1_1VehicleType.html',1,'OnlineMapsHereRoutingAPI']]],
  ['viawaypoint',['ViaWaypoint',['../classOnlineMapsGoogleDirectionsResult_1_1ViaWaypoint.html',1,'OnlineMapsGoogleDirectionsResult']]]
];
