var searchData=
[
  ['bizext',['BizExt',['../classOnlineMapsAMapSearchResult_1_1BizExt.html',1,'OnlineMapsAMapSearchResult']]],
  ['bounds',['Bounds',['../classOnlineMapsGPXObject_1_1Bounds.html',1,'OnlineMapsGPXObject']]]
];
