var searchData=
[
  ['beforeupdate',['BeforeUpdate',['../classOnlineMapsControlBase.html#ac7aade20b83c9358272c069e1ab48606',1,'OnlineMapsControlBase.BeforeUpdate()'],['../classOnlineMapsControlBase3D.html#ad44c58dc222ebe5a5180faf061bb5b20',1,'OnlineMapsControlBase3D.BeforeUpdate()'],['../classOnlineMapsUIImageControl.html#a284cb8587247b4b7dad83182642a01ae',1,'OnlineMapsUIImageControl.BeforeUpdate()'],['../classOnlineMapsUIRawImageControl.html#a7afab02fea52255a1922fb6ceee4013f',1,'OnlineMapsUIRawImageControl.BeforeUpdate()']]],
  ['bounds',['Bounds',['../classOnlineMapsGPXObject_1_1Bounds.html#a94e61228eea8b299a906f3705685d19f',1,'OnlineMapsGPXObject.Bounds.Bounds(OnlineMapsXML node)'],['../classOnlineMapsGPXObject_1_1Bounds.html#aa4a558fa48129764efa79bc830405b15',1,'OnlineMapsGPXObject.Bounds.Bounds(double minlon, double minlat, double maxlon, double maxlat)']]]
];
