var classOnlineMapsGoogleDirectionsResult_1_1TextValueZone =
[
    [ "text", "classOnlineMapsGoogleDirectionsResult_1_1TextValueZone.html#ab0237e95a479404881029846afd4c330", null ],
    [ "time_zone", "classOnlineMapsGoogleDirectionsResult_1_1TextValueZone.html#a7dd5567a64f45c5dfea1dc0ba3c02a83", null ],
    [ "value", "classOnlineMapsGoogleDirectionsResult_1_1TextValueZone.html#a23ae47b579adec5b144cf261be43cd56", null ]
];