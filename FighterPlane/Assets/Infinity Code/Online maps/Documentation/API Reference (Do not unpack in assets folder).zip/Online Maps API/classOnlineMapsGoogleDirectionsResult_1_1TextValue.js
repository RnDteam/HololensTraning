var classOnlineMapsGoogleDirectionsResult_1_1TextValue =
[
    [ "text", "classOnlineMapsGoogleDirectionsResult_1_1TextValue.html#a552b93fdbee2d62b9811f6540634df98", null ],
    [ "value", "classOnlineMapsGoogleDirectionsResult_1_1TextValue.html#a98f2cc481962693d6f9588f2063bd05c", null ]
];